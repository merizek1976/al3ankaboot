
const products = [
    { id: 1, name: "ساعة ذكية", price: 4500 },
    { id: 2, name: "هاتف محمول", price: 20000 },
    { id: 3, name: "سماعات لاسلكية", price: 3500 }
];

function renderProducts() {
    const list = document.getElementById('product-list');
    if (list) {
        products.forEach(p => {
            const item = document.createElement('div');
            item.innerHTML = `<h3>${p.name}</h3><p>${p.price} DA</p>
                              <button onclick="addToCart(${p.id})">أضف للسلة</button>`;
            list.appendChild(item);
        });
    }
}

function addToCart(id) {
    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    cart[id] = (cart[id] || 0) + 1;
    localStorage.setItem('cart', JSON.stringify(cart));
    alert("تمت الإضافة إلى السلة!");
}

function renderCart() {
    const cartItems = document.getElementById('cart-items');
    if (!cartItems) return;

    let cart = JSON.parse(localStorage.getItem('cart')) || {};
    for (let id in cart) {
        const product = products.find(p => p.id == id);
        const qty = cart[id];
        const item = document.createElement('div');
        item.innerHTML = `<h3>${product.name}</h3><p>الكمية: ${qty}</p><p>السعر: ${qty * product.price} DA</p>`;
        cartItems.appendChild(item);
    }
}

window.onload = function () {
    renderProducts();
    renderCart();
};
